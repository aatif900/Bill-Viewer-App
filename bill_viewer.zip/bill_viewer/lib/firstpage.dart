import 'package:bill_viewer/guidance.dart';
import 'package:bill_viewer/main.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Fpage extends StatefulWidget {
  const Fpage({super.key});

  @override
  State<Fpage> createState() => _FpageState();
}

class _FpageState extends State<Fpage> {
  var mtextstyle30 = const TextStyle(
    color: Colors.white,
    fontSize: 31.0,
    fontWeight: FontWeight.bold,
  );
  final sw= Get.size.width;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Bills Viewer App"),
        backgroundColor: Colors.pinkAccent,
      ),
      body: Padding(
        padding:  EdgeInsets.all(sw*0.1),
        child: Container(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: 50,
                  width: 400,
                  child: ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all(Colors.pinkAccent),
                          shape: MaterialStateProperty.all(RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)))),
                      onPressed: () {
                        Get.to(() => const MyHomePage(title: 'Check Your Bills'));
                      },
                      child: Text(
                        "Check Bills",
                        style: mtextstyle30,
                      )),
                ),
                const SizedBox(height: 40),
                SizedBox(
                  height: 50,
                  width: 400,
                  child: ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all(Colors.pinkAccent),
                          shape: MaterialStateProperty.all(RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)))),
                      onPressed: () {
                        Get.to(() => const guidance());
                      },
                      child: Text(
                        "Energy Saving Tips",
                        style: mtextstyle30,
                      )),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
