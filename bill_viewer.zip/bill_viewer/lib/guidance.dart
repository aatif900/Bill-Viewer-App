import 'package:flutter/material.dart';
import 'package:get/get.dart';

class guidance extends StatefulWidget {
  const guidance({super.key});

  @override
  State<guidance> createState() => _guidanceState();
}

class _guidanceState extends State<guidance> {
  final sw = Get.size.width;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Saving Tips"),
        backgroundColor: Colors.pinkAccent,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: sw * 0.05),
        child: Container(
          child: Column(
            children: [
              const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 100,
                  ),
                  Text(
                    "Energy Saving Tips",
                    style: TextStyle(
                        fontSize: 41,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                SizedBox(
                  height: 100,
                ),
              ]),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(
                  height: 30,
                  width: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    color: Colors.pinkAccent,
                  ),
                  child: const Text(
                    "1",
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        fontSize: 20),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                Container(
                  height: 30,
                  width: 350,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    color: Colors.pinkAccent,
                  ),
                  child: const Text(
                    "Use Energy-Efficient Appliances",
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        fontSize: 20),
                    textAlign: TextAlign.center,
                  ),
                ),
              ]),
              const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                SizedBox(
                  height: 20,
                ),
              ]),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(
                  height: 30,
                  width: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    color: Colors.pinkAccent,
                  ),
                  child: const Text(
                    "2",
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        fontSize: 20),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                Container(
                  height: 30,
                  width: 350,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    color: Colors.pinkAccent,
                  ),
                  child: const Text(
                    "Switch to LED Bulbs",
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        fontSize: 20),
                    textAlign: TextAlign.center,
                  ),
                ),
              ]),
              const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                SizedBox(
                  height: 20,
                ),
              ]),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(
                  height: 30,
                  width: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    color: Colors.pinkAccent,
                  ),
                  child: const Text(
                    "3",
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        fontSize: 20),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                Container(
                  height: 30,
                  width: 350,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    color: Colors.pinkAccent,
                  ),
                  child: const Text(
                    "Use Natural Light",
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        fontSize: 20),
                    textAlign: TextAlign.center,
                  ),
                ),
              ]),
              const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                SizedBox(
                  height: 20,
                ),
              ]),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(
                  height: 30,
                  width: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    color: Colors.pinkAccent,
                  ),
                  child: const Text(
                    "4",
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        fontSize: 20),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                Container(
                  height: 30,
                  width: 350,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    color: Colors.pinkAccent,
                  ),
                  child: const Text(
                    "Air Dry Laundry",
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        fontSize: 20),
                    textAlign: TextAlign.center,
                  ),
                ),
              ]),
              const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                SizedBox(
                  height: 20,
                ),
              ]),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(
                  height: 30,
                  width: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    color: Colors.pinkAccent,
                  ),
                  child: const Text(
                    "5",
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        fontSize: 20),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(
                  width: 25,
                ),
                Container(
                  height: 30,
                  width: 350,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    color: Colors.pinkAccent,
                  ),
                  child: const Text(
                    "Turn off Lights and Fans",
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        fontSize: 20),
                    textAlign: TextAlign.center,
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}
