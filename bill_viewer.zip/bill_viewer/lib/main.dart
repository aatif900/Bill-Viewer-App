import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bill_viewer/splashscreen.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    final screenWidth = Get.size.width;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pinkAccent,
        title: Text(widget.title),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.1),
        child: Container(
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              children: [
                const SizedBox(
                  height: 40,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Image.asset(
                      'assets/images/iesco.jpg',
                      height: 50,
                      width: 100,
                    ),
                    const SizedBox(
                      width: 100,
                    ),
                    Image.asset(
                      'assets/images/mepco.jpg',
                      height: 50,
                      width: 100,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.pinkAccent)),
                        onPressed: () {
                          launch('https://bill.pitc.com.pk/iescobill');
                        },
                        child: const Text(
                          'IESCO',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              decoration: TextDecoration.underline),
                        )),
                    const SizedBox(
                      width: 100,
                    ),
                    ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.pinkAccent)),
                        onPressed: () {
                          launch('https://mepcobill.pk');
                        },
                        child: const Text(
                          'MEPCO',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              decoration: TextDecoration.underline),
                        )),
                  ],
                ),
                const SizedBox(
                  height: 40,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // const SizedBox(
                    //   height: 150,
                    // ),
                    Image.asset(
                      'assets/images/lesco.jpg',
                      height: 100,
                      width: 100,
                    ),
                    const SizedBox(
                      width: 100,
                    ),
                    Image.asset(
                      'assets/images/pesco.jpg',
                      height: 100,
                      width: 100,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // const SizedBox(
                    //   height: 150,
                    // ),
                    ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.pinkAccent)),
                        onPressed: () {
                          launch('https://lesco.com.pk/');
                        },
                        child: const Text(
                          'LESCO',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              decoration: TextDecoration.underline),
                        )),
                    const SizedBox(
                      width: 100,
                    ),
                    ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.pinkAccent)),
                        onPressed: () {
                          launch('https://bill.pitc.com.pk/pescobill');
                        },
                        child: const Text(
                          'PESCO',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              decoration: TextDecoration.underline),
                        )),
                  ],
                ),
                const SizedBox(
                  height: 40,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // const SizedBox(
                    //   height: 150,
                    // ),
                    Image.asset(
                      'assets/images/qesco.jpg',
                      height: 100,
                      width: 100,
                    ),
                    const SizedBox(
                      width: 100,
                    ),
                    Image.asset(
                      'assets/images/fesco.png',
                      height: 100,
                      width: 100,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // const SizedBox(
                    //   height: 150,
                    // ),
                    ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.pinkAccent)),
                        onPressed: () {
                          launch('https://bill.pitc.com.pk/qescobill/');
                        },
                        child: const Text(
                          'QESCO',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              decoration: TextDecoration.underline),
                        )),
                    const SizedBox(
                      width: 100,
                    ),
                    ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.pinkAccent)),
                        onPressed: () {
                          launch('https://bill.pitc.com.pk/fescobill');
                        },
                        child: const Text(
                          'FESCO',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              decoration: TextDecoration.underline),
                        )),
                  ],
                ),
                const SizedBox(
                  height: 40,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // const SizedBox(
                    //   height: 150,
                    // ),
                    Image.asset(
                      'assets/images/hesco.png',
                      height: 100,
                      width: 100,
                    ),
                    const SizedBox(
                      width: 100,
                    ),
                    Image.asset(
                      'assets/images/sepco.jpg',
                      height: 100,
                      width: 100,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // const SizedBox(
                    //   height: 150,
                    // ),
                    ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.pinkAccent)),
                        onPressed: () {
                          launch('https://bill.pitc.com.pk/hescobill');
                        },
                        child: const Text(
                          'HESCO',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              decoration: TextDecoration.underline),
                        )),
                    const SizedBox(
                      width: 100,
                    ),
                    ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.pinkAccent)),
                        onPressed: () {
                          launch('https://bill.pitc.com.pk/sepcobill');
                        },
                        child: const Text(
                          'SEPCO',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              decoration: TextDecoration.underline),
                        )),
                  ],
                ),
                const SizedBox(
                  height: 40,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // const SizedBox(
                    //   height: 150,
                    // ),
                    Image.asset(
                      'assets/images/gepco.jpg',
                      height: 100,
                      width: 100,
                    ),
                    const SizedBox(
                      width: 100,
                    ),
                    Image.asset(
                      'assets/images/sgnpl.png',
                      height: 100,
                      width: 100,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // const SizedBox(
                    //   height: 150,
                    // ),
                    ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.pinkAccent)),
                        onPressed: () {
                          launch('https://bill.pitc.com.pk/gepcobill');
                        },
                        child: const Text(
                          'GEPCO',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              decoration: TextDecoration.underline),
                        )),
                    const SizedBox(
                      width: 100,
                    ),
                    ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.pinkAccent)),
                        onPressed: () {
                          launch('https://www.sngpl.com.pk/login.jsp?mdids=85');
                        },
                        child: const Text(
                          'SGNPL',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                              decoration: TextDecoration.underline),
                        )),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
